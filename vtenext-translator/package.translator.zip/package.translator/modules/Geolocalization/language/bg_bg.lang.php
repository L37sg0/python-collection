<?php
$mod_strings = array(
	'Geolocalization' => 'Геолокализация',
);
?> 
